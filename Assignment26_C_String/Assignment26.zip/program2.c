#include<stdio.h>
int Frequency(char *str, char ch)
{
	int iCnt=0;
	while(*str!='\0')
	{
		if(*str==ch)
		{
			iCnt++;
		}
		str++;
	}
	return iCnt;
}

int main()
{
	char Arr[20];
	char cValue='\0';
	int iRet=0;
	
	puts("Enter the string \n");
	gets(Arr);
	
	printf("Enter the chracter\n");
	scanf("%c",&cValue);
	
	iRet=Frequency(Arr,cValue);
	printf("%d",iRet);
	
	return 0;
}
													
