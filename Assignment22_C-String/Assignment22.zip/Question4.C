//Accpect character from user and check whether it is capital or not....
//(A-Z)
#include<stdio.h> 
#define TRUE 1
#define FALSE 0
typedef int BOOL;

bool  ChkSmall(char ch)
{
       if( (ch >='a'&& ch <='z'))
       {
        return true;
       }
       else
       {
        return false;
       }
}
int main()
{
    char cValue='\0';
    bool bRet=false;
    printf("Enter the character");
    scanf("%c",&cValue);
    bRet=ChkSmall(cValue);


    if(bRet==true)
    {
        printf("It is Small case Character");

    }
    else
    {
        printf("it is not a Small Case Character character");
    }
    return 0;

}