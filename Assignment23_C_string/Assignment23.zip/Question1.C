#include<stdio.h>
void DisplayASCII()
{   
    int iCnt=0;
    for(iCnt=0;iCnt<=127;iCnt++)
    {
        printf("Decimal value:%d Hexadeciamal:%x Character: %c \n ",iCnt,iCnt,iCnt);
    }



}
int main()
{
    DisplayASCII();

    return 0;

}